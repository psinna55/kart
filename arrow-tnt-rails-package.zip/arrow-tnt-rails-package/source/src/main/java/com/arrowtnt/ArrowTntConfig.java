package com.arrowtnt;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Настройки мода: config/arrowtnt.json. Файл перечитывается "на лету" при изменении
 * (проверка раз в 5 секунд), перезапуск игры не нужен.
 */
public class ArrowTntConfig {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("arrowtnt.json");
	private static long lastModified = -1;

	public static ArrowTntConfig INSTANCE = new ArrowTntConfig();

	/** Включить/выключить мод. */
	public boolean enabled = true;
	/** Тики между попаданием стрелы и взрывом вагонетки (20 тиков = 1 секунда). 0 = мгновенно. */
	public int fuseTicksAfterHit = 0;
	/** Взорвать вагонетку через N тиков полёта, даже если стрела ещё летит. 0 = отключено. */
	public int flightFuseTicks = 0;
	/** Сила взрыва (у обычного TNT = 4.0). */
	public float explosionPower = 4.0f;
	/** Разрушает ли взрыв блоки. */
	public boolean destroyBlocks = true;
	/** Только стрелы, выпущенные игроками. */
	public boolean onlyPlayerArrows = true;
	/** Через сколько тиков после установки рельса он исчезает. 0 = сразу после пролёта стрелы. */
	public int railLifetimeTicks = 40;

	public static void load() {
		try {
			if (Files.exists(PATH)) {
				ArrowTntConfig loaded = GSON.fromJson(Files.readString(PATH), ArrowTntConfig.class);
				if (loaded != null) {
					INSTANCE = loaded;
				}
			}
			INSTANCE.sanitize();
			Files.writeString(PATH, GSON.toJson(INSTANCE)); // дописывает недостающие поля
			lastModified = Files.getLastModifiedTime(PATH).toMillis();
		} catch (Exception e) {
			System.err.println("[arrowtnt] Не удалось загрузить конфиг: " + e);
		}
	}

	public static void reloadIfChanged() {
		try {
			if (Files.exists(PATH) && Files.getLastModifiedTime(PATH).toMillis() != lastModified) {
				load();
			}
		} catch (IOException ignored) {
		}
	}

	private void sanitize() {
		fuseTicksAfterHit = Math.max(0, fuseTicksAfterHit);
		flightFuseTicks = Math.max(0, flightFuseTicks);
		railLifetimeTicks = Math.max(0, railLifetimeTicks);
		explosionPower = Math.max(0f, Math.min(100f, explosionPower));
	}
}
