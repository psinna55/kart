package com.arrowtnt.mixin;

import com.arrowtnt.ArrowTntManager;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.BaseRailBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.redstone.Orientation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Рельсы мода висят в воздухе, поэтому ванильная проверка опоры для них отключается. */
@Mixin(BaseRailBlock.class)
public abstract class BaseRailBlockMixin {
	@Inject(method = "neighborChanged", at = @At("HEAD"), cancellable = true)
	private void arrowtnt$keepRail(BlockState state, Level level, BlockPos pos, Block block,
			Orientation orientation, boolean movedByPiston, CallbackInfo ci) {
		if (ArrowTntManager.isManaged(pos)) {
			ci.cancel();
		}
	}

	@Inject(method = "canSurvive", at = @At("HEAD"), cancellable = true)
	private void arrowtnt$survive(BlockState state, LevelReader level, BlockPos pos,
			CallbackInfoReturnable<Boolean> cir) {
		if (ArrowTntManager.isManaged(pos)) {
			cir.setReturnValue(true);
		}
	}
}
