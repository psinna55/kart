package com.arrowtnt;

import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.ThrownTrident;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.RailShape;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/**
 * Для каждой стрелы игрока создаётся вагонетка с TNT, которая летит под стрелой по рельсам,
 * укладываемым прямо в воздухе. При попадании запускается фитиль и вагонетка взрывается.
 */
public final class ArrowTntManager {
	/** setBlock: обновить клиентов (2) + не обновлять форму соседей (16) + без дропа (32). */
	private static final int QUIET_FLAGS = 2 | 16 | 32;

	private static final List<Tracked> TRACKED = new ArrayList<>();
	private static final List<PlacedRail> RAILS = new ArrayList<>();
	/** Позиции рельсов мода (используется миксином, чтобы рельсы не ломались без опоры). */
	private static final Set<Long> MANAGED = new HashSet<>();
	private static long time = 0;

	private ArrowTntManager() {
	}

	public static boolean isManaged(BlockPos pos) {
		return !MANAGED.isEmpty() && MANAGED.contains(pos.asLong());
	}

	public static void onEntityLoad(Entity entity, ServerLevel level) {
		ArrowTntConfig cfg = ArrowTntConfig.INSTANCE;
		if (!cfg.enabled || !(entity instanceof AbstractArrow arrow) || arrow instanceof ThrownTrident) {
			return;
		}
		// Только свежевыпущенные стрелы (не подгруженные из чанка)
		if (arrow.tickCount > 0 || arrow.isRemoved()) {
			return;
		}
		if (cfg.onlyPlayerArrows && !(arrow.getOwner() instanceof Player)) {
			return;
		}
		for (Tracked t : TRACKED) {
			if (t.arrow == arrow) {
				return;
			}
		}
		TRACKED.add(new Tracked(arrow));
	}

	public static void tick(MinecraftServer server) {
		time++;
		if (time % 100 == 0) {
			ArrowTntConfig.reloadIfChanged();
		}
		ArrowTntConfig cfg = ArrowTntConfig.INSTANCE;

		Iterator<Tracked> it = TRACKED.iterator();
		while (it.hasNext()) {
			if (tickTracked(it.next(), cfg)) {
				it.remove();
			}
		}
		expireRails(false);
	}

	/** @return true, если запись можно удалить */
	private static boolean tickTracked(Tracked t, ArrowTntConfig cfg) {
		AbstractArrow arrow = t.arrow;
		if (!(arrow.level() instanceof ServerLevel level)) {
			discardCart(t);
			return true;
		}

		if (t.fuseLeft < 0) { // стрела ещё в полёте
			boolean hit = false;
			if (arrow.isRemoved()) {
				// Выгрузка чанка / смена измерения — не взрываем
				if (arrow.getRemovalReason() == null || !arrow.getRemovalReason().shouldDestroy()) {
					discardCart(t);
					return true;
				}
				hit = true;
			} else {
				Vec3 pos = arrow.position();
				if (t.lastPos != null && pos.distanceToSqr(t.lastPos) < 1.0E-4) {
					t.stillTicks++;
				} else {
					t.stillTicks = 0;
				}
				t.lastPos = pos;
				if (t.stillTicks >= 2) {
					hit = true; // застряла в блоке
				}
			}

			if (!hit) {
				t.age++;
				followArrow(t, level, cfg);
				if (cfg.flightFuseTicks > 0 && t.age >= cfg.flightFuseTicks) {
					hit = true;
				}
			}
			if (hit) {
				t.fuseLeft = cfg.fuseTicksAfterHit;
			}
		}

		if (t.fuseLeft >= 0) {
			if (t.fuseLeft == 0) {
				explode(t, level, cfg);
				return true;
			}
			t.fuseLeft--;
		}
		return false;
	}

	private static void followArrow(Tracked t, ServerLevel level, ArrowTntConfig cfg) {
		AbstractArrow arrow = t.arrow;
		BlockPos railPos = BlockPos.containing(arrow.getX(), arrow.getY(), arrow.getZ()).below();
		Vec3 motion = arrow.getDeltaMovement();

		placeRail(level, railPos, motion, cfg);

		if (t.cart == null || t.cart.isRemoved()) {
			Entity cart = EntityType.TNT_MINECART.create(level, EntitySpawnReason.TRIGGERED);
			if (cart == null) {
				return;
			}
			cart.setNoGravity(true);
			cart.setInvulnerable(true);
			cart.setPos(arrow.getX(), railPos.getY() + 0.0625, arrow.getZ());
			level.addFreshEntity(cart);
			t.cart = cart;
		}
		t.cart.setDeltaMovement(Vec3.ZERO);
		t.cart.setPos(arrow.getX(), railPos.getY() + 0.0625, arrow.getZ());
		t.cart.fallDistance = 0;
	}

	private static void placeRail(ServerLevel level, BlockPos pos, Vec3 motion, ArrowTntConfig cfg) {
		BlockState current = level.getBlockState(pos);
		if (current.is(Blocks.RAIL) && MANAGED.contains(pos.asLong())) {
			return; // уже наш рельс
		}
		if (!(current.isAir() || (current.canBeReplaced() && current.getFluidState().isEmpty()))) {
			return;
		}
		RailShape shape = Math.abs(motion.x) >= Math.abs(motion.z) ? RailShape.EAST_WEST : RailShape.NORTH_SOUTH;
		BlockPos immutable = pos.immutable();
		MANAGED.add(immutable.asLong());
		level.setBlock(immutable,
				Blocks.RAIL.defaultBlockState().setValue(BlockStateProperties.RAIL_SHAPE, shape), QUIET_FLAGS);
		RAILS.add(new PlacedRail(level, immutable, time + cfg.railLifetimeTicks));
	}

	private static void explode(Tracked t, ServerLevel level, ArrowTntConfig cfg) {
		double x, y, z;
		if (t.cart != null && !t.cart.isRemoved()) {
			x = t.cart.getX();
			y = t.cart.getY() + 0.5;
			z = t.cart.getZ();
		} else {
			x = t.arrow.getX();
			y = t.arrow.getY();
			z = t.arrow.getZ();
		}
		Entity source = t.cart;
		level.explode(source, x, y, z, cfg.explosionPower,
				cfg.destroyBlocks ? Level.ExplosionInteraction.TNT : Level.ExplosionInteraction.NONE);
		discardCart(t);
		if (!t.arrow.isRemoved()) {
			t.arrow.discard();
		}
	}

	private static void discardCart(Tracked t) {
		if (t.cart != null && !t.cart.isRemoved()) {
			t.cart.discard();
		}
		t.cart = null;
	}

	private static void expireRails(boolean all) {
		Iterator<PlacedRail> it = RAILS.iterator();
		while (it.hasNext()) {
			PlacedRail r = it.next();
			if (all || r.expireAt() <= time) {
				if (r.level().getBlockState(r.pos()).is(Blocks.RAIL)) {
					r.level().setBlock(r.pos(), Blocks.AIR.defaultBlockState(), QUIET_FLAGS);
				}
				MANAGED.remove(r.pos().asLong());
				it.remove();
			}
		}
	}

	public static void clearAll() {
		for (Tracked t : TRACKED) {
			discardCart(t);
		}
		TRACKED.clear();
		expireRails(true);
		MANAGED.clear();
	}

	private static final class Tracked {
		final AbstractArrow arrow;
		Entity cart;
		Vec3 lastPos;
		int stillTicks;
		int age;
		int fuseLeft = -1;

		Tracked(AbstractArrow arrow) {
			this.arrow = arrow;
		}
	}

	private record PlacedRail(ServerLevel level, BlockPos pos, long expireAt) {
	}
}
