package com.arrowtnt;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

public class ArrowTntMod implements ModInitializer {
	public static final String MOD_ID = "arrowtnt";

	@Override
	public void onInitialize() {
		ArrowTntConfig.load();
		ServerEntityEvents.ENTITY_LOAD.register(ArrowTntManager::onEntityLoad);
		ServerTickEvents.END_SERVER_TICK.register(ArrowTntManager::tick);
		ServerLifecycleEvents.SERVER_STOPPING.register(server -> ArrowTntManager.clearAll());
	}
}
