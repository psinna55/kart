# Arrow TNT Rails (Fabric, Minecraft 1.21.11)

Под летящей стрелой игрока укладываются рельсы, а вагонетка с TNT летит вместе со стрелой
и взрывается при попадании.

## Сборка
Нужны JDK 21 и Gradle. Файлов `gradlew`/`gradle-wrapper.jar` в проекте нет — возьмите их из
https://github.com/FabricMC/fabric-example-mod (ветка 1.21.11) или выполните `gradle wrapper`, затем:

    ./gradlew build

Готовый мод: `build/libs/arrow-tnt-rails-1.0.0.jar` (нужен Fabric API).

## Настройки — `config/arrowtnt.json` (создаётся при первом запуске, перечитывается каждые ~5 сек)
| Поле | По умолчанию | Описание |
|---|---|---|
| enabled | true | вкл/выкл мод |
| fuseTicksAfterHit | 0 | тиков от попадания до взрыва (20 = 1 сек) |
| flightFuseTicks | 0 | взрыв через N тиков полёта; 0 — только при попадании |
| explosionPower | 4.0 | сила взрыва (TNT = 4) |
| destroyBlocks | true | ломает ли взрыв блоки |
| onlyPlayerArrows | true | только стрелы игроков |
| railLifetimeTicks | 40 | через сколько тиков исчезает рельс |
